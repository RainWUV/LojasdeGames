import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaLogin extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoSenha;
    private JButton btnLogin;
    private JButton btnEntrarComoConvidado;

    public TelaLogin() {
        setTitle("Login");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE); // Fundo branco

        // Painel Central com GridBagLayout para melhor controle de posicionamento
        JPanel panelCentral = new JPanel(new GridBagLayout());
        panelCentral.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblUsuario = new JLabel("Usuário:");
        campoUsuario = new JTextField(20);
        JLabel lblSenha = new JLabel("Senha:");
        campoSenha = new JPasswordField(20);

        // Estilizando rótulos
        lblUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSenha.setFont(new Font("Arial", Font.PLAIN, 14));

        // Estilizando campos de texto
        campoUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
        campoSenha.setFont(new Font("Arial", Font.PLAIN, 14));
        campoUsuario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 100)),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        campoSenha.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 100)),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));

        // Botão de Login estilizado
        btnLogin = new JButton("Login");
        btnLogin.setPreferredSize(new Dimension(100, 40));
        btnLogin.setBackground(new Color(255, 102, 0)); // Laranja
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false); // Remove a borda de foco

        // Botão "Entrar como Convidado" estilizado
        btnEntrarComoConvidado = new JButton("Entrar como Convidado");
        btnEntrarComoConvidado.setPreferredSize(new Dimension(200, 40));
        btnEntrarComoConvidado.setBackground(new Color(0, 153, 51)); // Verde escuro
        btnEntrarComoConvidado.setForeground(Color.WHITE);
        btnEntrarComoConvidado.setFocusPainted(false); // Remove a borda de foco

        // Adicionando componentes ao painel central com GridBagConstraints
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentral.add(lblUsuario, gbc);

        gbc.gridx = 1;
        panelCentral.add(campoUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentral.add(lblSenha, gbc);

        gbc.gridx = 1;
        panelCentral.add(campoSenha, gbc);

        // Painel de Botões com FlowLayout para os botões ficarem lado a lado
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotoes.setBackground(Color.WHITE);
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panelBotoes.add(btnLogin);
        panelBotoes.add(btnEntrarComoConvidado);

        // Adicionando painéis ao JFrame
        add(panelCentral, BorderLayout.CENTER);
        add(panelBotoes, BorderLayout.SOUTH);

        // Ação do botão Login
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String senha = new String(campoSenha.getPassword());
                // Lógica de autenticação - exemplo simples
                if ("Gustavo".equals(usuario) && "admin".equals(senha)) {
                    JOptionPane.showMessageDialog(null, "Login realizado com sucesso!");
                    dispose(); // Fecha a tela de login após o login ser bem-sucedido
                    abrirTelaPrincipal(); // Exemplo de método para abrir a próxima tela
                } else {
                    JOptionPane.showMessageDialog(null, "Usuário ou senha incorretos. Tente novamente.");
                    campoUsuario.setText("");
                    campoSenha.setText("");
                    campoUsuario.requestFocus(); // Coloca o foco de volta no campo de usuário
                }
            }
        });

        // Ação do botão Entrar como Convidado
        btnEntrarComoConvidado.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Entrando como convidado...");
                dispose(); // Fecha a tela de login após entrar como convidado
                abrirTelaPrincipal(); // Exemplo de método para abrir a próxima tela
            }
        });
    }

    // Método para abrir a próxima tela (exemplo)
    private void abrirTelaPrincipal() {
        SwingUtilities.invokeLater(() -> {
            new TelaVitrineProdutos().setVisible(true); // Exemplo de como abrir a próxima tela
        });
    }

    // Método principal para iniciar a aplicação
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaLogin().setVisible(true); // Inicia a tela de login
        });
    }
}







