import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class TelaCarrinho extends JFrame {

    private JTable tabelaCarrinho;
    private JButton btnFinalizarCompra;
    private List<Produto> produtosCarrinho;

    public TelaCarrinho(List<Produto> produtos) {
        setTitle("Carrinho de Compras");
        setSize(800, 600); // Tamanho ajustado para melhor visualização
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 240, 240)); // Fundo cinza claro

        produtosCarrinho = produtos;

        // Criação dos dados para a tabela
        String[] colunas = {"Produto", "Preço"};
        Object[][] dados = new Object[produtosCarrinho.size()][2];

        for (int i = 0; i < produtosCarrinho.size(); i++) {
            Produto produto = produtosCarrinho.get(i);
            dados[i][0] = produto.getNome();
            dados[i][1] = "R$ " + produto.getPreco();
        }

        DefaultTableModel model = new DefaultTableModel(dados, colunas);
        tabelaCarrinho = new JTable(model);
        tabelaCarrinho.setFont(new Font("Arial", Font.PLAIN, 16));
        tabelaCarrinho.setRowHeight(30); // Altura das linhas aumentada para melhor legibilidade
        JScrollPane scrollPane = new JScrollPane(tabelaCarrinho);
        add(scrollPane, BorderLayout.CENTER);

        // Painel para os botões de formas de pagamento
        JPanel panelPagamento = new JPanel(new GridLayout(0, 1, 10, 10));
        panelPagamento.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), "Forma de Pagamento"));
        panelPagamento.setBackground(new Color(240, 240, 240));

        JButton btnPix = criarBotaoPagamento("Pix", new Color(63, 81, 181)); // Azul índigo
        JButton btnBoleto = criarBotaoPagamento("Boleto", new Color(244, 67, 54)); // Vermelho
        JButton btnCartao = criarBotaoPagamento("Cartão de Crédito", new Color(33, 150, 243)); // Azul claro

        panelPagamento.add(btnPix);
        panelPagamento.add(btnBoleto);
        panelPagamento.add(btnCartao);

        add(panelPagamento, BorderLayout.EAST);

        // Botão para finalizar compra
        btnFinalizarCompra = new JButton("Finalizar Compra");
        btnFinalizarCompra.setBackground(new Color(255, 193, 7)); // Amarelo
        btnFinalizarCompra.setForeground(Color.WHITE); // Texto branco
        btnFinalizarCompra.setFont(new Font("Arial", Font.BOLD, 18));
        btnFinalizarCompra.setFocusPainted(false); // Sem foco
        btnFinalizarCompra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(TelaCarrinho.this, "Compra finalizada!");
                dispose(); // Fecha a tela de carrinho após finalizar compra
            }
        });

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotoes.setBackground(new Color(240, 240, 240)); // Fundo cinza claro
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBotoes.add(btnFinalizarCompra);

        add(panelBotoes, BorderLayout.SOUTH);
    }

    private JButton criarBotaoPagamento(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE); // Texto branco
        botao.setFont(new Font("Arial", Font.BOLD, 16));
        botao.setFocusPainted(false); // Sem foco
        botao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarPagamento(texto);
            }
        });
        return botao;
    }

    private void realizarPagamento(String formaPagamento) {
        // Implemente aqui a lógica para realizar o pagamento conforme a forma selecionada
        JOptionPane.showMessageDialog(this, "Pagamento realizado via " + formaPagamento);
    }

    public static void main(String[] args) {
        // Exemplo de uso: SwingUtilities.invokeLater(() -> new TelaCarrinho(new ArrayList<>()).setVisible(true));
    }
}











