import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaPagamento extends JFrame {

    public TelaPagamento(List<Produto> produtos, String formaPagamento) {
        setTitle("Pagamento");
        setSize(600, 400); // Tamanho ajustado para melhor visualização
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 240, 240)); // Fundo cinza claro

        JPanel panelTitulo = new JPanel();
        panelTitulo.setBackground(new Color(100, 149, 237)); // Azul claro
        panelTitulo.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel lblTitulo = new JLabel("Forma de Pagamento: " + formaPagamento);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setForeground(Color.WHITE); // Texto branco
        panelTitulo.add(lblTitulo);

        add(panelTitulo, BorderLayout.NORTH);

        JPanel panelInformacoes = new JPanel(new GridLayout(0, 1, 10, 10));
        panelInformacoes.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblInfo1 = new JLabel("Resumo da Compra:");
        lblInfo1.setFont(new Font("Arial", Font.BOLD, 16));
        panelInformacoes.add(lblInfo1);

        // Criação dos dados para a tabela
        String[] colunas = {"Produto", "Preço"};
        Object[][] dados = new Object[produtos.size()][2];

        for (int i = 0; i < produtos.size(); i++) {
            Produto produto = produtos.get(i);
            dados[i][0] = produto.getNome();
            dados[i][1] = "R$ " + produto.getPreco();
        }

        DefaultTableModel model = new DefaultTableModel(dados, colunas);
        JTable tabelaProdutos = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tabelaProdutos);

        panelInformacoes.add(scrollPane);

        JLabel lblInfo2 = new JLabel("Total: R$ " + calcularTotalCompra(produtos));
        lblInfo2.setFont(new Font("Arial", Font.BOLD, 16));
        panelInformacoes.add(lblInfo2);

        JLabel lblInfo3 = new JLabel("Forma de Pagamento selecionada: " + formaPagamento);
        lblInfo3.setFont(new Font("Arial", Font.BOLD, 16));
        panelInformacoes.add(lblInfo3);

        add(panelInformacoes, BorderLayout.CENTER);

        JButton btnConfirmar = new JButton("Confirmar Pagamento");
        btnConfirmar.setBackground(new Color(76, 175, 80)); // Verde
        btnConfirmar.setForeground(Color.WHITE); // Texto branco
        btnConfirmar.setFont(new Font("Arial", Font.BOLD, 18));
        btnConfirmar.setFocusPainted(false); // Sem foco
        btnConfirmar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Pagamento confirmado via " + formaPagamento);
            dispose(); // Fecha a tela de pagamento
        });

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotoes.add(btnConfirmar);

        add(panelBotoes, BorderLayout.SOUTH);
    }

    private double calcularTotalCompra(List<Produto> produtos) {
        double total = 0.0;
        for (Produto produto : produtos) {
            total += produto.getPreco();
        }
        return total;
    }

    public static void main(String[] args) {
        // Exemplo de uso: SwingUtilities.invokeLater(() -> new TelaPagamento(new ArrayList<>(), "Pix").setVisible(true));
    }
}





