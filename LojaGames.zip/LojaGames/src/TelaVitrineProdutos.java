import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class TelaVitrineProdutos extends JFrame {

    private JPanel panelPlayStation;
    private JPanel panelXbox;
    private JPanel panelNintendo;
    private List<Produto> produtosPlayStation;
    private List<Produto> produtosXbox;
    private List<Produto> produtosNintendo;
    private List<Produto> produtosSelecionados;

    public TelaVitrineProdutos() {
        setTitle("Vitrine de Produtos");
        setSize(1000, 800); // Aumentei o tamanho para acomodar mais produtos
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 3)); // Layout de grade com 3 colunas
        getContentPane().setBackground(new Color(255, 255, 255)); // Fundo branco

        // Inicializa as listas de produtos para cada marca
        produtosPlayStation = new ArrayList<>();
        produtosXbox = new ArrayList<>();
        produtosNintendo = new ArrayList<>();

        // Adiciona jogos da PlayStation
        produtosPlayStation.add(new Produto("The Last of Us Part II", 199.90));
        produtosPlayStation.add(new Produto("God of War", 149.90));
        produtosPlayStation.add(new Produto("Spider-Man: Miles Morales", 179.90));
        produtosPlayStation.add(new Produto("Bloodborne", 99.90));
        produtosPlayStation.add(new Produto("Ghost of Tsushima", 189.90));
        produtosPlayStation.add(new Produto("Demon's Souls", 209.90));
        produtosPlayStation.add(new Produto("Horizon Zero Dawn", 139.90));
        produtosPlayStation.add(new Produto("Ratchet & Clank: Rift Apart", 239.90));
        produtosPlayStation.add(new Produto("Uncharted 4: A Thief's End", 169.90));
        produtosPlayStation.add(new Produto("Death Stranding", 159.90));

        // Adiciona jogos do Xbox
        produtosXbox.add(new Produto("Halo Infinite", 249.90));
        produtosXbox.add(new Produto("Forza Horizon 5", 179.90));
        produtosXbox.add(new Produto("Gears 5", 159.90));
        produtosXbox.add(new Produto("Sea of Thieves", 129.90));
        produtosXbox.add(new Produto("Ori and the Will of the Wisps", 99.90));
        produtosXbox.add(new Produto("Fable", 229.90));
        produtosXbox.add(new Produto("State of Decay 2", 149.90));
        produtosXbox.add(new Produto("The Medium", 189.90));
        produtosXbox.add(new Produto("Microsoft Flight Simulator", 279.90));
        produtosXbox.add(new Produto("Psychonauts 2", 199.90));

        // Adiciona jogos da Nintendo
        produtosNintendo.add(new Produto("The Legend of Zelda: Breath of the Wild", 249.90));
        produtosNintendo.add(new Produto("Super Mario Odyssey", 199.90));
        produtosNintendo.add(new Produto("Animal Crossing: New Horizons", 179.90));
        produtosNintendo.add(new Produto("Mario Kart 8 Deluxe", 159.90));
        produtosNintendo.add(new Produto("Splatoon 2", 149.90));
        produtosNintendo.add(new Produto("Super Smash Bros. Ultimate", 229.90));
        produtosNintendo.add(new Produto("Pokémon Sword/Shield", 219.90));
        produtosNintendo.add(new Produto("Fire Emblem: Three Houses", 169.90));
        produtosNintendo.add(new Produto("Luigi's Mansion 3", 189.90));
        produtosNintendo.add(new Produto("Xenoblade Chronicles 2", 209.90));

        produtosSelecionados = new ArrayList<>();

        // Painel para produtos da PlayStation
        panelPlayStation = criarPanelMarca("PlayStation", produtosPlayStation, new Color(51, 102, 255));

        // Painel para produtos do Xbox
        panelXbox = criarPanelMarca("Xbox", produtosXbox, new Color(0, 153, 102));

        // Painel para produtos da Nintendo
        panelNintendo = criarPanelMarca("Nintendo", produtosNintendo, new Color(255, 0, 0));

        // Adiciona os painéis ao JFrame
        add(panelPlayStation);
        add(panelXbox);
        add(panelNintendo);

        // Botão para abrir o carrinho
        JButton btnCarrinho = new JButton("Ver Carrinho");
        btnCarrinho.setBackground(new Color(0, 153, 204)); // Azul água
        btnCarrinho.setForeground(Color.WHITE); // Texto branco
        btnCarrinho.setFont(new Font("Arial", Font.BOLD, 18));
        btnCarrinho.setFocusPainted(false); // Sem foco
        btnCarrinho.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaCarrinho();
            }
        });

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotoes.setBackground(new Color(240, 240, 240)); // Fundo cinza claro
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBotoes.add(btnCarrinho);

        // Adiciona o painel de botões ao final do JFrame
        add(panelBotoes, BorderLayout.SOUTH);
    }

    // Método para criar um painel para uma marca específica
    private JPanel criarPanelMarca(String marca, List<Produto> produtos, Color corFundo) {
        JPanel panelMarca = new JPanel(new BorderLayout());
        panelMarca.setBackground(corFundo);

        // Título da marca
        JLabel lblTitulo = new JLabel(marca);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.WHITE); // Texto branco
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelMarca.add(lblTitulo, BorderLayout.NORTH);

        // Painel para listar os produtos da marca
        JPanel panelProdutos = new JPanel(new GridLayout(0, 1, 20, 20)); // Uma coluna
        panelProdutos.setBackground(corFundo);
        panelProdutos.setBorder(new EmptyBorder(20, 40, 20, 40)); // Margens internas

        // Adiciona os produtos ao painel central
        for (Produto produto : produtos) {
            JPanel panelProduto = criarPanelProduto(produto);
            panelProdutos.add(panelProduto);
        }

        JScrollPane scrollPane = new JScrollPane(panelProdutos);
        panelMarca.add(scrollPane, BorderLayout.CENTER);

        return panelMarca;
    }

    // Método para criar um painel para um produto específico
    private JPanel criarPanelProduto(Produto produto) {
        JPanel panelProduto = new JPanel();
        panelProduto.setBackground(Color.WHITE);
        panelProduto.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));
        panelProduto.setLayout(new BorderLayout());

        JLabel lblNome = new JLabel(produto.getNome());
        lblNome.setFont(new Font("Arial", Font.BOLD, 20));
        lblNome.setHorizontalAlignment(SwingConstants.CENTER);
        panelProduto.add(lblNome, BorderLayout.CENTER);

        JLabel lblPreco = new JLabel("R$ " + produto.getPreco());
        lblPreco.setFont(new Font("Arial", Font.PLAIN, 18));
        lblPreco.setHorizontalAlignment(SwingConstants.CENTER);
        panelProduto.add(lblPreco, BorderLayout.SOUTH);

        JButton btnAdicionar = new JButton("Adicionar ao Carrinho");
        btnAdicionar.setBackground(new Color(0, 153, 102)); // Verde escuro
        btnAdicionar.setForeground(Color.WHITE); // Texto branco
        btnAdicionar.setFont(new Font("Arial", Font.BOLD, 16));
        btnAdicionar.setFocusPainted(false); // Sem foco
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarProdutoAoCarrinho(produto);
                btnAdicionar.setEnabled(false); // Desabilita após adicionar
                btnAdicionar.setText("Adicionado!");
            }
        });
        panelProduto.add(btnAdicionar, BorderLayout.PAGE_END);

        return panelProduto;
    }

    // Método para adicionar produtos ao carrinho
    private void adicionarProdutoAoCarrinho(Produto produto) {
        produtosSelecionados.add(produto);
        JOptionPane.showMessageDialog(this, produto.getNome() + " adicionado ao carrinho!");
    }

    // Método para abrir a tela de carrinho
    private void abrirTelaCarrinho() {
        SwingUtilities.invokeLater(() -> {
            new TelaCarrinho(produtosSelecionados).setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaVitrineProdutos().setVisible(true);
        });
    }
}
















